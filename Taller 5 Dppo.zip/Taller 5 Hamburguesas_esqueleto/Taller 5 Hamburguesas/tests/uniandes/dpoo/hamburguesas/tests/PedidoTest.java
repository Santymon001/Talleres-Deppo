package uniandes.dpoo.hamburguesas.tests;


import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import uniandes.dpoo.hamburguesas.mundo.Pedido;
import uniandes.dpoo.hamburguesas.mundo.ProductoMenu;

class PedidoTest {

    private Pedido pedido;

    @BeforeEach
    void setUp() {
        pedido = new Pedido("Juan Perez", "Calle 123");
        pedido.agregarProducto(new ProductoMenu("Hamburguesa Sencilla", 8000));
    }

    @Test
    void testGenerarTextoFactura() {
        String factura = pedido.generarTextoFactura();
        assertTrue(factura.contains("Hamburguesa Sencilla"));
        assertTrue(factura.contains("8000"));
    }

    @Test
    void testGuardarFactura() {
        // Implementar una prueba para verificar el guardado de la factura
    }
}
